import React, { Component } from 'react';
//import styles from "./Login.module.css";

import './Login.css';
class Login extends Component {
   
    render() {
        return (
            <div class="login-page_login">
                <div class="form_login">
                    <form class="login-form_login">
                        <input  type="text" placeholder="Enter username" />
                        <input type="password" placeholder="Enter password" />
                        <button >login</button>
                        <p class="message_login" >Not registered? <a href="#">Create an account</a></p>
                    </form>
                </div>
            </div>
        )
    }
}

export default Login;