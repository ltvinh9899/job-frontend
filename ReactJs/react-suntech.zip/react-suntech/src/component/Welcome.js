import React, { Component } from 'react'
import './Welcome.css';
import Logo from "./image/logo.png";
import { AiFillHome } from "react-icons/ai"
import { BsPeopleFill } from "react-icons/bs"
import { BsPeopleCircle } from "react-icons/bs"
import { BsSearch } from "react-icons/bs"
import { IoIosPeople } from "react-icons/io"
import Modal from 'react-awesome-modal'
import Login from './Login'
import SignUp from './SignUp'
import { BrowserRoute, BrowserRouter, Link, Route } from 'react-router-dom';
import Java from './JobComponent/javaJob'
class Welcome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      currentComponent: 'A'
    }
  }

  openModal() {
    this.setState({
      visible: true
    });
  }

  closeModal() {
    this.setState({
      visible: false
    });
  }

  render() {
    return (
      <div class="container">
        <div class="header_container">
          <div class="header">
            <div class="header_left">
              <img src={Logo} />
              <span>IT JOB FOR EVERYONE</span>
            </div>
            <div class="header_right">
              <ul>
                <li class="job">
                  <div >
                    <BsPeopleFill class="job_icon"></BsPeopleFill>
                    <span>Job</span>
                  </div>
                </li>
                <li class="company">
                  <Link to="/company_List" class="text-link" style={{textDecoration:'none', color:'white'}} >
                    <div>
                      <AiFillHome class="company_icon"></AiFillHome>
                      <span >Company</span>
                    </div>
                  </Link>
                </li>
                <li class="login">
                  <div>
                    <BsPeopleCircle class="login_icon" onClick={() => this.openModal()}></BsPeopleCircle>
                    <span onClick={() => this.openModal()}>Log In</span>

                    <Modal
                      visible={this.state.visible}
                      width="400"
                      height="400"
                      backgroundColor="red"
                      effect="fadeInUp"
                      onClickAway={() => this.closeModal()}
                    >
                      <div class="loginScreen">
                        <Login ></Login>
                      </div>
                    </Modal>
                  </div>
                </li>
                <li class="Signup">
                  <div>
                    <IoIosPeople class="signup_icon" onClick={() => this.openModal()}></IoIosPeople>
                    <span onClick={() => this.openModal()}>Sign Up</span>
                    <Modal
                      visible={this.state.visible}
                      width="400"
                      height="400"
                      backgroundColor="red"
                      effect="fadeInUp"
                      onClickAway={() => this.closeModal()}
                    >
                      <div>
                        <SignUp></SignUp>
                      </div>
                    </Modal>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="header_search">
            <input type="text" placeholder="Key word for finding job"></input>
            <div class="search_icon"><BsSearch></BsSearch></div>
            <div class="search_button">
              <span>Search</span>
            </div>
          </div>
          <div class="header_search_skill">
            <ul>

              <li><Link to="/java" className='text-link'  ><div>Java</div></Link></li>
              <li><Link to="/.NET" className='text-link'  ><div>.NET</div></Link></li>
              <li><Link to="/PHP" className='text-link'  ><div>PHP</div></Link></li>
              <li><Link to="/Nodejs" className='text-link'  ><div>NodeJs</div></Link></li>
              <li><Link to="/Android" className='text-link'  ><div>Android</div></Link></li>
              <li><Link to="/IOS" className='text-link'  ><div>IOS</div></Link></li>
              <li><Link to="/C++" className='text-link'  ><div>C++</div></Link></li>
            </ul>
          </div>
        </div>
        <div class="main_container">
          <div class="main_title">
            <span>Top Companies</span>
          </div>
          <div class="main_company">
            <div class="main_company_top">
              <ul>
                <li><div></div></li>
                <li><div></div></li>
                <li><div></div></li>
              </ul>
            </div>
            <div class="main_company_bottom">
              <ul>
                <li><div></div></li>
                <li><div></div></li>
                <li><div></div></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer_container">
          <div class="footer_search">
            <div class="footer_search_skill">
              <div>Jobs by Skill</div>
              <ul>
                <li><Link to="/java" className='text-link-footer'  ><div>Java</div></Link></li>
                <li><a>PHP</a></li>
                <li><a>.NET</a></li>
                <li><a>JavaScript</a></li>
                <li><a>NodeJS</a></li>
                <li><a>Android</a></li>
                <li><a>Ios</a></li>

              </ul>
            </div>
            <div class="footer_search_position">
              <div>Jobs by Position</div>
              <ul>
                <li><a>Internship</a></li>
                <li><a>Fresher</a></li>
                <li><a>Junior</a></li>
                <li><a>Leader</a></li>
                <li><a>Freelancer</a></li>
              </ul>
            </div>
            <div class="footer_search_company">
              <div>Jobs by Company</div>
              <ul>
                <li><a>GotIt</a></li>
                <li><a>Misa</a></li>
                <li><a>BKAV</a></li>
                <li><a>FPT Software</a></li>
                <li><a>Luvina</a></li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    )
  }
}
export default Welcome