import React, { Component } from 'react'
import { BrowserRouter, Route, Link , Switch} from "react-router-dom";
import Second from "./second"
import First from "./first"
class Container extends Component {
    render() {
        return (
                <BrowserRouter>
                    <Route path="/" component={First} exact /> 
                    <Route path="/second" component={Second} exact /> 
                </BrowserRouter>
        )
    }
}
export default Container;