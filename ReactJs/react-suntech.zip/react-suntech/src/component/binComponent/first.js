import React, { Component } from 'react'
import { BrowserRouter, Route, Link , Switch} from "react-router-dom";
//import './first.css'
import Second from "./second"
class First extends Component {
    render() {
        return (
              <div><button><Link to="/second">lucas</Link></button></div>
        )
    }
}
export default First;