import React, { Component } from 'react'
import { AiFillHome } from "react-icons/ai"
import { BsPeopleFill } from "react-icons/bs"
import { BsPeopleCircle } from "react-icons/bs"
import { BsSearch } from "react-icons/bs"
import { IoIosPeople } from "react-icons/io"
import { FaQuoteLeft } from "react-icons/fa"
import { FaQuoteRight } from "react-icons/fa"

import Modal from 'react-awesome-modal'
import Logo from "../image/logo.png";
import Logo_company from "../image/best_company.png";
import Star from "../image/star.png";
import Grab from "../image/grab-logo.png";
import { BrowserRoute, BrowserRouter, Link, Route } from 'react-router-dom';

//import Login from "../Login"
//import SignUp from "../SignUp"
import "./CompanyList.css"
class CompanyList extends Component {
    render() {
        return (
            <div class="container_company">
                <div class="header_company_list">
                    <div class="header_company_left">
                        <Link to="/" ><img src={Logo} /></Link>
                        <span>IT JOB FOR EVERYONE</span>
                    </div>
                    <div class="header_company_right">
                        <ul>
                            <li class="job">
                                <div >
                                    <BsPeopleFill class="job_icon"></BsPeopleFill>
                                    <span>Job</span>
                                </div>
                            </li>
                            <li class="company">
                                <div>
                                    <AiFillHome class="company_icon"></AiFillHome>
                                    <span >Company</span>
                                </div>
                            </li>
                            <li class="login">
                                <div>
                                    <BsPeopleCircle class="login_icon" onClick={() => this.openModal()}></BsPeopleCircle>
                                    <span onClick={() => this.openModal()}>Log In</span>
                                    {/*  <Modal
                                    visible={this.state.visible}
                                    width="400"
                                    height="400"
                                    backgroundColor="red"
                                    effect="fadeInUp"
                                    onClickAway={() => this.closeModal()}
                                >
                                    <div class="loginScreen">
                                        <Login ></Login>
                                    </div>
                                </Modal> */}
                                </div>
                            </li>
                            <li class="Signup">
                                <div>
                                    <IoIosPeople class="signup_icon" onClick={() => this.openModal()}></IoIosPeople>
                                    <span onClick={() => this.openModal()}>Sign Up</span>
                                    {/* <Modal
                                    visible={this.state.visible}
                                    width="400"
                                    height="400"
                                    backgroundColor="red"
                                    effect="fadeInUp"
                                    onClickAway={() => this.closeModal()}
                                >
                                    <div>
                                        <SignUp></SignUp>
                                    </div>
                                </Modal> */}
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="main_company_list">
                    <div class="introduce_main_company">
                        <div class="content_main_company">
                            <h1>Vietnam Best IT Companies 2019</h1>
                            <p>The employees have spoken! Here are the Top Vietnam Best IT Companies 2019 to work for based on 11,000+ reviews submitted by IT people.</p>
                        </div>
                        <div class="logo_main_company">
                            <div class="logo_best_company">
                                <img src={Logo_company} />

                            </div>
                        </div>
                        <div></div>
                    </div>
                    <div class="list_main_company">
                        <ul>
                            <li>
                                <div class="name_list_company">
                                    <h2>Grab Vietnam Ltd</h2>
                                </div>
                                <div class="other_introduce">
                                    <div class="frame_logo"><img src={Grab} /></div>
                                    <div class="comment_company">
                                        <ul>
                                            <li><div class="comment_company_star"><img src={Star} /></div></li>
                                            <li><div class="comment_company_star"><img src={Star} /></div></li>
                                            <li><div class="comment_company_star"><img src={Star} /></div></li>
                                            <li><div class="comment_company_star"><img src={Star} /></div></li>
                                        </ul>
                                        <div class="comment_company_icons">
                                            <div><FaQuoteLeft></FaQuoteLeft></div>
                                            <span>If you want to work with people who are the best, just come here.
                                            Grab encourages people to be open, helpful and transparent, and you will feel welcome day 1 here.
                                            Code you are writing WILL make impact on Grab, and by proxy Southest Asia...
                                           </span>
                                        </div>

                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div >
        )
    }
}
export default CompanyList;