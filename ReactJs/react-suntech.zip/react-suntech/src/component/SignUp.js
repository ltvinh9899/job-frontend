import React, { Component } from 'react';
import './SignUp.css';
class Login extends Component {
    render() {
        return (
            <div class="login-page_sign">
                <div class="form_sign">
                    <form class="register-form">
                        <input type="text" placeholder="Enter your username" />
                        <input type="password" placeholder="Enter your password" />
                        <button>REGISTER</button>
                        <p class="message_sign">Already registered? <a href="#">Sign In</a></p>
                    </form>
                </div>
            </div>
        )
    }
}

export default Login