import React, { Component } from 'react'
import ReactDOM from 'react-dom';
import { BrowserRoute, BrowserRouter, Link, Route } from 'react-router-dom';
import multiply from "./ViettelJob/image/multiply.png"
import "./apply.css"
class Apply extends Component {
    constructor(props) {
        super(props);
        this.wrapperRef = React.createRef();
        this.myRef=React.createRef();
        this.state = {
            selectedFileName: "",
            buttonName: "Select your CV",
        }

    }
    componentDidMount() {
        document.addEventListener('click', this.handleClick)
    }

    componentWillUnmount() {
        document.removeEventListener('click', this.handleClick)
    }
    handleClick = (event) => {
        const { target } = event
        if (!this.wrapperRef.current.contains(target)) {
             if (document.getElementById('name').value == "") {
            const element = <div>
                <img class="multiply_icons" src={multiply}></img>
                <p>can't be blank</p>
            </div>;
            ReactDOM.render(element, document.getElementsByClassName('form_error')[0]);
        }
        if (document.getElementById('cv').value == "") {
            const element = <div>
                <img class="multiply_icons" src={multiply}></img>
                <p>can't be blank</p>
            </div>;
            ReactDOM.render(element, document.getElementsByClassName('form_error')[1]);
        }
        }
    }

    handleselectedFile = event => {
        this.setState({
            selectedFile: event.target.files[0],
            selectedFileName: event.target.files[0].name,
            buttonName: event.target.files[0].name
        });
    }
    handleClick1 = (event) => {
        this.myRef.current.click();
    }
    child_closeModal() {
        this.props.parentMethod();
    }
    check_form() {
        if (document.getElementById('name').value == "") {
            const element = <div>
                <img class="multiply_icons" src={multiply}></img>
                <p>can't be blank</p>
            </div>;
            ReactDOM.render(element, document.getElementsByClassName('form_error')[0]);
        }
        if (document.getElementById('cv').value == "") {
            const element = <div>
                <img class="multiply_icons" src={multiply}></img>
                <p>can't be blank</p>
            </div>;
            ReactDOM.render(element, document.getElementsByClassName('form_error')[1]);
        }


    }
    render() {

        return (
            <div class="apply_container">
                <div class="apply_title">
                    <div class="apply_title_name">
                        <h1>Let's apply to look for suitable jobs</h1>
                    </div>
                </div>
                <div class="apply_form">
                    <div class="name_form">
                        <span>Your Name :</span>
                        <input type="text" placeholder="Enter your name" id="name" ref={this.wrapperRef} />
                    </div>
                    <div class="form_error"></div>

                    <div class="cv_form">
                        <span>  Your CV :</span>
                        <button onClick={this.handleClick1} >
                            <span>{this.state.buttonName}</span>
                        </button>
                        <input type="file"
                            ref={this.myRef}
                            style={{ display: 'none' }}
                            onChange={this.handleselectedFile}
                            accept=".png,.jpg"
                            id="cv"
                        />
                    </div>
                    <div class="form_error"></div>

                </div>
                <div class="sendCv_button">
                    <div class="cv_button" onClick={() => this.child_closeModal()}>
                        <span>Send your CV</span>
                    </div>
                </div>


            </div>
        );
    }

};
export default Apply;