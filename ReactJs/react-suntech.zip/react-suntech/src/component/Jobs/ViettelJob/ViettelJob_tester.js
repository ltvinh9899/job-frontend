import React, { Component } from 'react';
import Logo from "./image/logo.png";
import background_image from "./image/viettel.jpg"
import country from "./image/VN-Vietnam-Flag-icon.png"
import Viettel_logo from "./image/viettel-group-logo.jpg"
import { AiFillHome } from "react-icons/ai"
import { BsPeopleFill } from "react-icons/bs"
import { BsPeopleCircle } from "react-icons/bs"
import { BsSearch } from "react-icons/bs"
import { IoIosPeople } from "react-icons/io"
import { AiOutlineDollarCircle } from "react-icons/ai"
import { FaCity } from "react-icons/fa"
import { GiModernCity } from "react-icons/gi"
import { FaHome } from "react-icons/fa"
import { IoIosCalendar } from "react-icons/io"
import { BiMap } from "react-icons/bi"
import Modal from 'react-awesome-modal'
import { BrowserRoute, BrowserRouter, Link, Route } from 'react-router-dom';
import "./ViettelJob_tester.css"
import Apply from "../Apply"
class ViettelJob_tester extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false,
        }
    }
    boom(){
        alert("long")
    }
    openModal() {
        this.setState({
            visible: true
        });
    }

    closeModal() {
        this.setState({
            visible: false
        });
    }
    render() {
        return (
            <div class="container">
                <div class="header_company_list">
                    <div class="header_company_left">
                        <img src={Logo} />
                        {/*   <Link to="/" ><img src={Logo} /></Link> */}
                        <span>IT JOB FOR EVERYONE</span>
                    </div>
                    <div class="header_company_right">
                        <ul>
                            <li class="job">
                                <div >
                                    <BsPeopleFill class="job_icon"></BsPeopleFill>
                                    <span>Job</span>
                                </div>
                            </li>
                            <li class="company">
                                <div>
                                    <AiFillHome class="company_icon"></AiFillHome>
                                    <span >Company</span>
                                </div>
                            </li>
                            <li class="login">
                                <div>
                                    <BsPeopleCircle class="login_icon" onClick={() => this.openModal()}></BsPeopleCircle>
                                    <span onClick={() => this.openModal()}>Log In</span>

                                </div>
                            </li>
                            <li class="Signup">
                                <div>
                                    <IoIosPeople class="signup_icon" onClick={() => this.openModal()}></IoIosPeople>
                                    <span onClick={() => this.openModal()}>Sign Up</span>

                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="Viettel_tester_main">
                    <div class="Viettel_tester_main_image">
                        <img src={background_image} class="image" />
                    </div>
                    <div class="Viettel_tester_main_content">
                        <div class="Viettel_tester_main_content_logo">
                            <div class="Viettel_tester_main_content_logo_icon">
                                <img src={Viettel_logo}></img>
                            </div>
                            <div class="Viettel_tester_main_content_logo_infor">
                                <div class="Viettel_tester_main_content_logo_infor_title">
                                    <h1>Viettel Group</h1>
                                </div>
                                <div class="Viettel_tester_main_content_logo_infor_introduce">
                                    <ul>
                                        <li class="country">
                                            <div>
                                                <img src={country}></img>
                                                <div class="country_name"><span>Việt Nam</span></div>
                                            </div>
                                        </li>
                                        <li class="staff">
                                            <div>
                                                <BsPeopleFill class="staff_number"></BsPeopleFill>
                                                <div class="staff_name"><span>1000+</span></div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="schedule">
                                                <IoIosCalendar class="schedule_number"></IoIosCalendar>
                                                <div class="schedule_name"><span>Monday - Friday</span></div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="Viettel_tester_main_content_title">
                            <div class="Viettel_tester_main_content_title_name">
                                <h1>10 Kỹ sư kiểm thử phần mềm (Tester)</h1>
                            </div>
                            <div class="Viettel_tester_main_content_title_frame">
                                <ul>
                                    <li class="job_frame">
                                        <div>
                                            Tester
                                        </div>
                                    </li>
                                    <li class="company_frame">
                                        <div>
                                            Viettel
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="Viettel_tester_main_content_title_description">
                                <ul>
                                    <li class="salary_description">
                                        <div >
                                            <div class="icon"><AiOutlineDollarCircle></AiOutlineDollarCircle></div>
                                            <div class="text"><span>1000 - 2000 USD</span></div>
                                        </div>
                                    </li>
                                    <li class="address_description">
                                        <div>
                                            <div class="icon"><BiMap></BiMap></div>
                                            <div class="text"><span>Keangnam Landmark Tower, Pham Hung, Cau Giay, Ha Noi</span></div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>

                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="Viettel_tester_main_content_title_apply">
                                <div class="apply_button" onClick={() => this.openModal()}>
                                    <span>Apply Now</span>
                                </div>
                                <Modal
                                    visible={this.state.visible}
                                    width="900"
                                    height="350"
                                    backgroundColor="red"
                                    effect="fadeInUp"
                                    
                                >
                                    <div><Apply parentMethod={() => this.closeModal()}></Apply></div>
                                </Modal>
                            </div>
                            <div class="Viettel_tester_main_content_title_unique">
                                <ul>
                                    <li>
                                        <div>
                                            
                                        </div>
                                    </li>
                                    <li><div></div></li>
                                    <li><div></div></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )
    }

}
export default ViettelJob_tester;