import React, { Component } from 'react';
import Logo from "../image/logo.png";
import { AiFillHome } from "react-icons/ai"
import { BsPeopleFill } from "react-icons/bs"
import { BsPeopleCircle } from "react-icons/bs"
import { BsSearch } from "react-icons/bs"
import { IoIosPeople } from "react-icons/io"
import { AiOutlineDollarCircle } from "react-icons/ai"
import { FaCity } from "react-icons/fa"
import { GiModernCity } from "react-icons/gi"
import { FaHome } from "react-icons/fa"
import { BrowserRoute, BrowserRouter, Link, Route } from 'react-router-dom';

import "./Java.css"
class Java extends Component {

    render() {
        return (
            <div class="container">
                <div class="header_container">
                    <div class="header">
                        <div class="header_left">
                            <Link to="/" ><img src={Logo} /></Link>
                            <span>IT JOB FOR EVERYONE</span>
                        </div>
                        <div class="header_right">
                            <ul>
                                <li class="job">
                                    <div >
                                        <BsPeopleFill class="job_icon"></BsPeopleFill>
                                        <span>Job</span>
                                    </div>
                                </li>
                                <li class="company">
                                    <div>
                                        <Link to="/company_List" class="text-link" style={{ textDecoration: 'none', color: 'white' }} >
                                            <div>
                                                <AiFillHome class="company_icon"></AiFillHome>
                                                <span >Company</span>
                                            </div>
                                        </Link>
                                    </div>
                                </li>
                                <li class="login">
                                    <div>
                                        <BsPeopleCircle class="login_icon" onClick={() => this.openModal()}></BsPeopleCircle>
                                        <span >Log In</span>
                                    </div>
                                </li>
                                <li class="Signup">
                                    <div>
                                        <IoIosPeople class="signup_icon" onClick={() => this.openModal()}></IoIosPeople>
                                        <span >Sign Up</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="header_search_job"> 
                    <div class="header_search">
                        <input type="text" placeholder="Key word for finding job"></input>
                        <div class="search_icon"><BsSearch></BsSearch></div>
                        <div class="search_button">
                            <span>Search</span>
                        </div>
                    </div>
                </div>
                <div class="main_container_java">

                    <div class="numberJob">
                        <span>99 Java Jobs for you</span>
                    </div>
                    <div class="Job">
                        <div class="descriptionJob">
                            <div class="SpecificallyJob">
                                <div class="logoCompany">
                                    <div><img src={Logo} /></div>
                                </div>
                                <div class="contentJob">
                                    <div class="nameJob">5 java Dev</div>
                                    <div class="salaryJob">
                                        <div class="iconJob"><AiOutlineDollarCircle></AiOutlineDollarCircle></div>
                                        <span>700 - 1500 USD</span>
                                    </div>
                                    <div class="priorityJob">
                                        <ul>
                                            <li>Làm việc tại Hà Nội</li>
                                            <li>Được đóng bảo hiểm</li>
                                            <li>Môi trường làm việc năng động</li>
                                        </ul>
                                    </div>
                                    <div class="requiredJob">
                                        Tham gia phát triển các ứng dụng trên nền tảng Java cho khách hàng Nhật Bản
                                     <br />
                                     Tham gia đầy đủ các công đoạn của dự án từ tìm hiểu yêu cầu, phân tích,...
                                </div>
                                </div>
                                <div class="PlaceJob">
                                    <div class="city">
                                        <div class="icon">
                                            <FaCity ></FaCity>
                                        </div>
                                        <span>Hà Nội</span>

                                    </div>
                                    <div class="distric">
                                        <div class="icon">
                                            <GiModernCity ></GiModernCity>
                                        </div>
                                        <span>Cầu Giấy</span>
                                    </div>
                                    <div class="address">
                                        <div class="icon">
                                            <FaHome></FaHome>
                                        </div>
                                        <span>133 Hoàng Quốc Việt</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="Job">
                        <div class="descriptionJob">
                            <div class="SpecificallyJob">
                                <div class="logoCompany">
                                    <div><img src={Logo} /></div>
                                </div>
                                <div class="contentJob">
                                    <div class="nameJob">5 java Dev</div>
                                    <div class="salaryJob">
                                        <div class="iconJob"><AiOutlineDollarCircle></AiOutlineDollarCircle></div>
                                        <span>700 - 1500 USD</span>
                                    </div>
                                    <div class="priorityJob">
                                        <ul>
                                            <li>Làm việc tại Hà Nội</li>
                                            <li>Được đóng bảo hiểm</li>
                                            <li>Môi trường làm việc năng động</li>
                                        </ul>
                                    </div>
                                    <div class="requiredJob">
                                        Tham gia phát triển các ứng dụng trên nền tảng Java cho khách hàng Nhật Bản
                                     <br />
                                     Tham gia đầy đủ các công đoạn của dự án từ tìm hiểu yêu cầu, phân tích,...
                                </div>
                                </div>
                                <div class="PlaceJob">
                                    <div class="city">
                                        <div class="icon">
                                            <FaCity ></FaCity>
                                        </div>
                                        <span>Hà Nội</span>

                                    </div>
                                    <div class="distric">
                                        <div class="icon">
                                            <GiModernCity ></GiModernCity>
                                        </div>
                                        <span>Cầu Giấy</span>
                                    </div>
                                    <div class="address">
                                        <div class="icon">
                                            <FaHome></FaHome>
                                        </div>
                                        <span>133 Hoàng Quốc Việt</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="Job">
                        <div class="descriptionJob">
                            <div class="SpecificallyJob">
                                <div class="logoCompany">
                                    <div><img src={Logo} /></div>
                                </div>
                                <div class="contentJob">
                                    <div class="nameJob">5 java Dev</div>
                                    <div class="salaryJob">
                                        <div class="iconJob"><AiOutlineDollarCircle></AiOutlineDollarCircle></div>
                                        <span>700 - 1500 USD</span>
                                    </div>
                                    <div class="priorityJob">
                                        <ul>
                                            <li>Làm việc tại Hà Nội</li>
                                            <li>Được đóng bảo hiểm</li>
                                            <li>Môi trường làm việc năng động</li>
                                        </ul>
                                    </div>
                                    <div class="requiredJob">
                                        Tham gia phát triển các ứng dụng trên nền tảng Java cho khách hàng Nhật Bản
                                     <br />
                                     Tham gia đầy đủ các công đoạn của dự án từ tìm hiểu yêu cầu, phân tích,...
                                </div>
                                </div>
                                <div class="PlaceJob">
                                    <div class="city">
                                        <div class="icon">
                                            <FaCity ></FaCity>
                                        </div>
                                        <span>Hà Nội</span>

                                    </div>
                                    <div class="distric">
                                        <div class="icon">
                                            <GiModernCity ></GiModernCity>
                                        </div>
                                        <span>Cầu Giấy</span>
                                    </div>
                                    <div class="address">
                                        <div class="icon">
                                            <FaHome></FaHome>
                                        </div>
                                        <span>133 Hoàng Quốc Việt</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}
export default Java;