import React from 'react';
import Modals from './component/Modal'
import Login from './component/Login'
import Java from './component/JobComponent/javaJob'
import Welcome from './component/Welcome';
import logo from './logo.svg';
import './App.css';
import CompanyList from './component/CompanyComponent/CompanyList'


import ViettelJob_tester from './component/Jobs/ViettelJob/ViettelJob_tester'
import Apply from './component/Jobs/Apply'

import { Component } from 'react';
import { BrowserRouter, Route, Link , Switch} from "react-router-dom";
class App extends Component {
    render() {
        return (
            /*  <BrowserRouter>
                <Route path="/" component={Welcome} exact />
                <Route path="/java" component={Java} exact />
                <Route path="/Company_List" component={CompanyList} exact />
            </BrowserRouter>  */
            //<ViettelJob_tester></ViettelJob_tester>
            <ViettelJob_tester></ViettelJob_tester>
        
           
        )
    }
}

export default App;
